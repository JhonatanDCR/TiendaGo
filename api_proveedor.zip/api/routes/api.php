<?php
use App\Http\Controllers\Api\ProveedorController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::controller(ProveedorController::class)->group(function () {
    Route::get('/proveedores', 'index');
    Route::post('/proveedor', 'store');
    Route::get('/proveedor/{id}', 'show');
    Route::put('/proveedor/{id}', 'update');
    Route::delete('/proveedor/{id}', 'destroy');
});