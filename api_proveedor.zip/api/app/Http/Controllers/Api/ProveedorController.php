<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Proveedor;

class ProveedorController extends Controller
{
    public function index()
    {
        $provee = Proveedor::all();
        return $provee;
    }

    public function store(Request $request)
    {
        $provee = new Proveedor();
        $provee-> nombre = $request -> nombre;
        $provee->rubro = $request -> rubro;
        $provee->ubicacion = $request -> ubicacion;
        $provee->celular = $request -> celular;
        $provee->telefono = $request -> telefono;
        $provee-> save();
    }
    
    public function show($id)
    {
        $provee = Proveedor::find($id);
        return $provee;
    }

    
    public function update(Request $request, $id)
    {
        $provee = Proveedor::findOrFail($request -> id);
        $provee-> nombre = $request -> nombre;
        $provee->rubro = $request -> rubro;
        $provee->ubicacion = $request -> ubicacion;
        $provee->celular = $request -> celular;
        $provee->telefono = $request -> telefono;
        $provee-> save();
        return $provee;
    }

    public function destroy($id)
    {
        $provee=Proveedor::destroy($id);
        return $provee;
    }
}
